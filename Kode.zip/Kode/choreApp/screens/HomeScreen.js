import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, SafeAreaView, ScrollView, TextInput, TouchableOpacity, Text as CustomText } from 'react-native';
import { useEffect, useState } from 'react'; 
import { getDatabase, ref, onValue } from 'firebase/database';

export default function HomeScreen() {
  //States til at holde input for personens navn & opgaver 
  const [personName, setPersonName] = useState(''); 
  const [chores, setChores] = useState([]); 
  const [filteredChores, setFilteredChores] = useState([]); //State til at holde de filtrerede opgaver

  const fetchChores = () => {
    const db = getDatabase(); 
    const choresRef = ref(db, 'chores'); //Reference til 'chores'-noden i databasen

    //Lyt til databasen og hent alle opgaver
    onValue(choresRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        //Konverterer det returnerede objekt til et array af opgaver
        const choresArray = Object.keys(data).map(key => ({
          id: key,
          ...data[key],
        }));
        setChores(choresArray);
      } else {
        setChores([]); //Ingen data i databasen
      }
    });
  };

  //Funktion til at filtrere opgaver baseret på personens navn (case-insensitive)
  const filterChoresByPerson = () => {
    const filtered = chores.filter(chore =>
      chore.person.toLowerCase() === personName.toLowerCase()
    );
    setFilteredChores(filtered);
  };

  useEffect(() => {
    //Hent opgaver fra Firebase når komponentet indlæses
    fetchChores();
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.welcomeText}>Welcome to the home screen!</Text>
      
      {/* Input til at indtaste personens navn */}<TextInput
      style={styles.input}
      placeholder="Enter person's name"
      value={personName}
      onChangeText={setPersonName}
      />

      {/* Custom-knap til at starte filtreringen */}
      <TouchableOpacity style={styles.button} onPress={filterChoresByPerson}>
        <CustomText style={styles.text}>Find Chores</CustomText>
      </TouchableOpacity>

      {/* Viser filtrerede opgaver*/}
      <ScrollView style={styles.choresList} contentContainerStyle={filteredChores.length === 0 ? styles.centeredContent : null}>
        {filteredChores.length > 0 ? (
          filteredChores.map((chore, index) => (
          <View key={index} style={styles.choreContainer}>
            <Text style={styles.choreText}>Chore: {chore.chore}</Text>
            <Text style={styles.choreText}>Assigned to: {chore.person}</Text>
            <Text style={styles.choreText}>Deadline: {chore.deadline}</Text>
            </View>
            ))
  ) : (
    //Vises hvis ingen opgaver findes
    <View style={styles.noChoresContainer}>
      <Text style={styles.noChoresText}>No chores found :)</Text>
    </View>
  )}
</ScrollView>

      {/* Statusbar til at styre statuslinjen på mobilen */}
      <StatusBar style="auto" />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  welcomeText: {
    marginTop: 30,
    fontSize: 24,
    fontFamily: 'Avenir', 
    fontWeight: 'bold', 
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginVertical: 10,
    paddingHorizontal: 10,
    width: '90%',
    marginTop: 100
  },
  choresList: {
    marginTop: 20,
    width: '100%',
  },
  choreContainer: {
    padding: 10,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 5,
    marginBottom: 10,
    width: '90%',
    alignSelf: 'center'
  },
  choreText: {
    fontSize: 16,
  },
  noChoresContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: 200, 
  },
  noChoresText: {
    fontSize: 16,
    color: 'gray',
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: 'blue',
    margin: 20,
    width: 200
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: 'bold',
    letterSpacing: 0.30,
    color: 'white',
    fontFamily: 'Avenir',
  },
});


