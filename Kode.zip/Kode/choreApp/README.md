*Start*
// 1. Kør "npm install"

*Opstart af Firebase*
// 2. Kør "npm i firebase"

*Opstart af app*
// 2. Kør "npx expo start" (hvis ikke det virker kør "npx expo start --tunnel")