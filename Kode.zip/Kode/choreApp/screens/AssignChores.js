import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TextInput, ScrollView, TouchableOpacity, Text as CustomText } from 'react-native';
import { useState } from 'react';
import { getDatabase, ref, push, set } from 'firebase/database';

export default function AssignChores({ navigation }) { 

  //States til at håndtere chore, person & deadline input 
  const [chore, setChore] = useState(''); 
  const [person, setPerson] = useState(''); 
  const [deadline, setDeadline] = useState(''); 
  const [assignedChores, setAssignedChores] = useState([]); //State til at gemme listen over chores, personer & deadlines

  // Firebase database reference
  const database = getDatabase(); 

  //Funktion til at håndtere tilføjelsen af opgaven, personen og deadline til listen og databasen
  const handleAddAssignment = () => {
    if (chore.trim() && person.trim() && deadline.trim()) { //Tilføj kun hvis alle inputs er udfyldt
      console.log("Attempting to add chore..."); //Fejlfinding 

      //Gem til Firebase Realtime Database
      const choreRef = ref(database, 'chores'); //Opret en reference til "chores"-noden i databasen
      const newChoreRef = push(choreRef); //Opret en ny post i databasen
      
      //Brug set() direkte på den nye choreRef - set() bruges til at gemme data i databasen
      set(newChoreRef, {
        chore: chore,
        person: person,
        deadline: deadline,
      }).then(() => {
        console.log("Chore successfully saved to the database");
      }).catch((error) => {
        console.error("Error saving chore to the database:", error);
      });

      //Opdater den lokale state
      setAssignedChores([...assignedChores, { chore, person, deadline }]); //Tilføj den nye opgave til arrayet
      //Tøm chore, person & deadline input 
      setChore(''); 
      setPerson(''); 
      setDeadline(''); 
    } else {
      console.log("Chore, person, or deadline is missing.");
    }
  };

  return (
    <View style={styles.container}>
      <Text>Assign a chore</Text>

      {/* TextInput til at indtaste opgaven */}
      <TextInput
        style={styles.input}
        placeholder="Enter chore"
        value={chore}
        onChangeText={setChore} //Opdaterer state med den indtastede opgave
      />

      {/* TextInput til at indtaste person */}
      <TextInput
        style={styles.input}
        placeholder="Enter person assigned"
        value={person}
        onChangeText={setPerson}
      />

      {/* TextInput til at indtaste deadline */}
      <TextInput
        style={styles.input}
        placeholder="Enter deadline"
        value={deadline}
        onChangeText={setDeadline}
      />

      {/* Custom-knap til at tilføje opgaven */}
      <TouchableOpacity style={styles.button} onPress={handleAddAssignment}>
        <CustomText style={styles.text}>Assign Chore</CustomText>
      </TouchableOpacity>

      {/* Viser listen af tildelte opgaver ovenpå hinanden */}
      <ScrollView style={styles.assignmentList}>
        {assignedChores.map((assignment, index) => (
          <View key={index} style={styles.assignmentContainer}>
            <Text style={styles.assignmentLabel}>Chore:</Text>
            <Text style={styles.assignmentText}>{assignment.chore}</Text>
            <Text style={styles.assignmentLabel}>Assigned to:</Text>
            <Text style={styles.assignmentText}>{assignment.person}</Text>
            <Text style={styles.assignmentLabel}>Deadline:</Text>
            <Text style={styles.assignmentText}>{assignment.deadline}</Text>
          </View>
        ))}
      </ScrollView>

       {/* StatusBar, der styrer statusbjælken på mobilen */}
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginVertical: 10,
    paddingHorizontal: 10,
    width: '100%',
  },
  assignmentList: {
    marginTop: 20,
    width: '100%',
    maxHeight: 200,
  },
  assignmentContainer: {
    marginBottom: 20,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginVertical: 10,
    paddingHorizontal: 10,
    width: '100%',
  },
  assignmentLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
  },
  assignmentText: {
    fontSize: 18,
    color: 'blue',
    marginBottom: 5,
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: 'blue',
    margin: 20,
    width: 200
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: 'bold',
    letterSpacing: 0.30,
    color: 'white',
    fontFamily: 'Avenir',
  },
});
